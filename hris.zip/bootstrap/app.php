<?php

date_default_timezone_set('Asia/Manila'); //CDT

require __DIR__ . '/../vendor/autoload.php';

$app = new \Slim\App([ //Init Slim App
    'settings' => [
        'displayErrorDetails' => true,
        //'determineRouteBeforeAppMiddleware' => false,
        //'addContentLengthHeader' => false,
    'db' => [
        'driver' => 'mysql',
        'host' => 'localhost',
        'database' => 'hris',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'collation' => 'utf8_unicode_ci',
        'prefix' => ''
    ]],
]); 

$container = $app->getContainer(); //Init Container

//$app->add(new \App\Middleware\AuthMiddleware($container));
$app->add(function ($request, $response, $next) {
	$response->getBody()->write('BEFORE');
	$response = $next($request, $response);
	$response->getBody()->write('AFTER');

	return $response;
});

$app->get('/', function ($request, $response, $args) {
	$response->getBody()->write(' Hello ');

	return $response;
});

require __DIR__ .'/dependencies.php';

$container['db'] = function($container) use ($capsule){
    return $capsule;
};

$container['jwt'] = function($container) {
    return new StdClass;
};

$container['logger'] = function($container) {
    $logger = new \Monolog\Logger('my_logger');
    $logger->pushHandler(new \Monolog\Handler\StreamHandler('../logs/app.log'));
    return $logger;
};

$container['HomeController'] = function($container) {
    return new \App\Modules\Authorization\Controllers\HomeController($container); 
};

$container['AuthController'] = function($container) {
    return new \App\Modules\Authorization\Controllers\AuthController;
};

$container['EmployeeController'] = function($container) {
    return new \App\Modules\Employee\Controllers\EmployeeController($container);
};

$container['validator'] = function($container){
    return new \App\Utils\Validator;
};

//Adding Middleware
require __DIR__ . '/../src/routes.php'; //Route Summary
//$app->add(new \App\Middleware\ValidationErrorsMiddleware()); 





