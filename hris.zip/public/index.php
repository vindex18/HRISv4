<?php

require __DIR__ . '/../bootstrap/app.php';

// Start App
$app->run();