<?php

$app->get('/attendance/getallattendance', 'AttendanceController:getAllAttendance');
$app->get('/attendance/getattendance/', '');