<?php

namespace App\Modules\Authorization\Service;
use App\Modules\Authorization\Models\AuthModel;
use Respect\Validation\Validator as v;
use App\Utils\Validator;
use \Datetime;
use \Firebase\JWT\JWT;
use \Tuupola\Base62;
use App\Middleware\AuthMiddleware;

class AuthService {
    function validatecredentials($req, $res){
        $validation = Validator::validate($req, [
            'password' => v::noWhitespace()->notEmpty()->length(6, null),
            'email' => v::noWhitespace()->notEmpty()->email(),
        ]); 

        if(!is_null($validation))
            return $res->withJSON($validation);
            
        $userexists = AuthModel::where('email', '=', strip_tags($req->getParam('email')))->first();
        if(is_null($userexists))
            return $res->withJSON(array(
                                    'status' => 'val_error',
                                    'msg' => 'Email doesn\'t exists!'
                                 ));
        else{
            if(password_verify(strip_tags($req->getParam('password')), $userexists->password))
                return array('status' => 'success', 'msg' => 'Login Success', 'tk' => AuthService::generate_jwt($req, $res));
            else
                return array('status' => 'failed', 'msg' => 'Incorrect Email/Password!', 'tk' => '');
        }
    }

    function generate_jwt($req, $res){
        $now = new DateTime();
        $future = new DateTime("now +2 hours");
        //$server = $req->getServerParams();
        $base62 = new \Tuupola\Base62;
        $payload = [
            'iat' => $now->getTimeStamp(),
            'exp' => $future->getTimeStamp(),
            'jti' => $base62->encode(random_bytes(32)),
            //'sub' => $server['PHP_AUTH_USER']
        ];

        $secret = "Q!w12x2512g1c2a4Wa23Kpb752x&95z*";
        $data = array('token' => JWT::encode($payload, $secret, "HS256"), 'expires' => $future->getTimeStamp());
        //$data = "";
        return $data;
    }

}