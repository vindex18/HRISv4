<?php
$app->post('/authorization/validatecredentials', 'AuthController:validatecredentials');
