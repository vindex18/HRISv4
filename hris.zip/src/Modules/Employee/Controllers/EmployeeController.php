<?php 

namespace App\Modules\Employee\Controllers;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use App\Modules\Employee\Service\EmployeeService;

class EmployeeController {
    function __construct(){
        return "This is the Employee Controller";
    }

    function getAllEmployee(){
        var_dump(EmployeeService::getAllEmployee());
    }

    function addEmployee($req, $res){
        return var_dump(EmployeeService::addEmployee($req, $res));
    }

    function getEmployee($req, $res, $args){
        //var_dump($args);
         //var_dump($req);
        return $res->withJSON(EmployeeService::getEmployee($req, $res, $args));
    }
}