<?php

namespace App\Modules\Employee\Service;

use App\Modules\Employee\Models\EmployeeModel;
use Respect\Validation\Validator as v;
use App\Utils\Validator;

class EmployeeService {

    function __construct($container){

    }
    
    function getAllEmployee(){
        return EmployeeModel::all();
    }

    function checkEmailExists($email){
        return EmployeeModel::where('email', '=', strip_tags($email))->first();
    }

    function addEmployee($req, $res){
        $validation = Validator::validate($req, [
            'firstname' => v::notEmpty()->alpha(),
            'lastname' => v::notEmpty()->alpha(),
            'middlename' => v::notEmpty()->alpha(),
            'password' => v::noWhitespace()->notEmpty()->length(6, null),
            'email' => v::noWhitespace()->notEmpty()->email(),
        ]); 
        
        if(!is_null($validation))
           return $res->withJSON($validation);
        
        $userexists = EmployeeService::checkEmailExists(strip_tags($req->getParam('email')));
    
        if(!is_null($userexists)){
            var_dump("user Already exists\n<br>"); 
            return $res->withJSON(array('status' => 'val_error',
                                             'msg' => 'Email Already Exists!')); 
        }
        else{
            $qry = EmployeeModel::firstOrcreate([
                                'first_name' => strip_tags($req->getParam('firstname')), 
                                'last_name' => strip_tags($req->getParam('lastname')),
                                'middle_name' => strip_tags($req->getParam('middlename')),
                                'phone' => strip_tags($req->getParam('phone')),
                                'email' => strip_tags($req->getParam('email')),
                                'address' => strip_tags($req->getParam('address')),
                                'pos_title' => strip_tags($req->getParam('postitle')),
                                'password' => password_hash(strip_tags($req->getParam('password')), PASSWORD_DEFAULT)
                                ])->save();

            return $res->withJSON($qry ? true : false);
        }
    }

    function getEmployee($req, $res, $args){
        //var_dump($req); die();
         return var_dump(EmployeeModel::where('id', strip_tags($req->getAttribute('emp_id')))
                ->first());
    }
}
