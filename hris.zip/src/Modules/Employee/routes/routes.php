<?php

$app->post('/employee/addemployee', 'EmployeeController:addEmployee'); //Add
$app->get('/employee/getemployee/{emp_id:[0-9]+}', 'EmployeeController:getEmployee'); //Get Single Emp Rec
$app->get('/employee/getallemployee', 'EmployeeController:getAllEmployee'); //Get All Emp Rec
$app->delete('/employee/deleteemployee', 'EmployeeController::deleteEmployee'); //Delete Single Emp Rec
$app->put('/employee/updateemployee', 'EmployeeController::updateEmployee'); //Update Single Emp Rec