<?php

namespace App\Modules\Authorization\Controllers;

use App\Modules\Authorization\Service\AuthService;

class AuthController {
    public function __construct(){
        var_dump("\nAuthController Constructed!1");
    }

    public function index(){
        //$emp = AuthModel::where('last_name', 'Reyes');
        //var_dump($emp);
    }

    public function validatecredentials($req, $res){
        return $res->withJSON(AuthService::validatecredentials($req, $res), 201);
    }
}