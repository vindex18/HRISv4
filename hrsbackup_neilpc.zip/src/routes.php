<?php

/*$data = $request->getParsedBody();
    $ticket_data = [];
    $ticket_data['title'] = filter_var($data['title'], FILTER_SANITIZE_STRING);
    $ticket_data['description'] = filter_var($data['description'], FILTER_SANITIZE_STRING);
    */
/*$app->get('/', function($response, $request){ //HomeController:index
    $home = new HomeController();
    return new $home->index();
});*/

require __DIR__ . '/Modules/Employee/routes/routes.php'; //Employee Routes
require __DIR__ .'/Modules/Authorization/routes/routes.php'; //Authorization Routes

